/*

*/


#include "qtparapinwidgets.h"

// Parapin-Includes 
#include <fcntl.h>					/* open, fcntl */
#include <sys/ioctl.h>				/* ioctl */
#include <stdio.h>					/* printf, getchar */
#include <stdlib.h>					/* exit */
#include <parapindriver.h>			/* parapindriver */
#include <unistd.h> 				/* close, read, usleep */ 
#include <iostream>

int parapindevice;
bool m_parapinloaded;

QtParapinWidgets::QtParapinWidgets( QWidget * parent, Qt::WindowFlags f) : QDialog(parent,f)
{
	setupUi(this);
}

QtParapinWidgets::~QtParapinWidgets()
{
}
void QtParapinWidgets::on_pushButtonOpen_clicked()
{
qWarning("Open from: %s	%d",__FILE__,__LINE__);

	parapindevice = ::open("/dev/ppdrv_device", 0);
		if (parapindevice < 0)
		{
		fprintf(stderr, "Open ppdrv-device failed !\n");
		m_parapinloaded = false;
		label->setText( "Error!" );
//		exit(-1);	
		}
		else
		{
		m_parapinloaded = true;
		label->setText( "Success!" );
		ioctl(parapindevice, PPDRV_IOC_PINMODE_OUT, LP_PIN02);
		ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN02 | LP_PIN09);
		usleep(1000000);
		ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN02 | LP_PIN09);
		}
}


void QtParapinWidgets::on_pushButtonClose_clicked()
{
	qWarning("Close-from: %s	%d",__FILE__,__LINE__);

	if ( m_parapinloaded == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN02 | LP_PIN03 | LP_PIN04 | LP_PIN05 | LP_PIN06 | LP_PIN07 | LP_PIN08 | LP_PIN09);

	QtParapinWidgets::radioButton_2->setChecked(false);
	QtParapinWidgets::radioButton_3->setChecked(false);
	QtParapinWidgets::radioButton_4->setChecked(false);
	QtParapinWidgets::radioButton_5->setChecked(false);
	QtParapinWidgets::radioButton_6->setChecked(false);
	QtParapinWidgets::radioButton_7->setChecked(false);
	QtParapinWidgets::radioButton_8->setChecked(false);
	QtParapinWidgets::radioButton_9->setChecked(false);

	::close(parapindevice);
	m_parapinloaded = false;
	label->setText( "Removed!" );
	}
}

void QtParapinWidgets::on_pushButton_2_clicked()
{
	qWarning("Button2 from: %s	%d",__FILE__,__LINE__);

	if (radioButton_2->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN02);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN02);
	}
}

void QtParapinWidgets::on_pushButton_3_clicked()
{
	qWarning("Button3 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_3->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN03);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN03);
	}
}

void QtParapinWidgets::on_pushButton_4_clicked()
{
	qWarning("Button4 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_4->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN04);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN04);
	}
}

void QtParapinWidgets::on_pushButton_5_clicked()
{
	qWarning("Button5 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_5->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN05);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN05);
	}
}

void QtParapinWidgets::on_pushButton_6_clicked()
{
	qWarning("Button6 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_6->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN06);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN06);
	}
}

void QtParapinWidgets::on_pushButton_7_clicked()
{
	qWarning("Button7 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_7->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN07);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN07);
	}
}

void QtParapinWidgets::on_pushButton_8_clicked()
{
	qWarning("Button8 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_8->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN08);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN08);
	}
}

void QtParapinWidgets::on_pushButton_9_clicked()
{
	qWarning("Button9 from: %s	%d",__FILE__,__LINE__);
	if (radioButton_9->isChecked() == true)
	{
	ioctl(parapindevice, PPDRV_IOC_PINSET, LP_PIN09);
	}
	else
	{
	ioctl(parapindevice, PPDRV_IOC_PINCLEAR, LP_PIN09);
	}
}



void QtParapinWidgets::on_radioButton_2_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_3_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_4_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_5_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_6_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_7_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_8_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_radioButton_9_toggled(bool)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_buttonBox_helpRequested()
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

void QtParapinWidgets::on_buttonBox_clicked(QAbstractButton*)
{
	qWarning("TODO: %s	%d",__FILE__,__LINE__);
}

