#ifndef QTPARAPINWIDGETS_H
#define QTPARAPINWIDGETS_H

#include "ui_qtparapinwidgets.h"
#include <QDialog>

class QtParapinWidgets : public QDialog , private Ui::Dialog
{
Q_OBJECT
public:
	QtParapinWidgets( QWidget * parent = 0, Qt::WindowFlags f = 0 );
	~QtParapinWidgets();
protected slots:
	void on_buttonBox_helpRequested();
	void on_buttonBox_clicked(QAbstractButton*);
	void on_pushButton_2_clicked();
	void on_radioButton_2_toggled(bool);
	void on_pushButton_3_clicked();
	void on_radioButton_3_toggled(bool);
	void on_radioButton_5_toggled(bool);
	void on_pushButton_4_clicked();
	void on_radioButton_4_toggled(bool);
	void on_pushButton_5_clicked();
	void on_pushButton_8_clicked();
	void on_radioButton_7_toggled(bool);
	void on_radioButton_8_toggled(bool);
	void on_pushButton_6_clicked();
	void on_radioButton_6_toggled(bool);
	void on_pushButton_9_clicked();
	void on_radioButton_9_toggled(bool);
	void on_pushButton_7_clicked();
	void on_pushButtonOpen_clicked();
	void on_pushButtonClose_clicked();
	
};
#endif //QTPARAPINWIDGETS_H
